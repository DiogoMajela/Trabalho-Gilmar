package pkgClientesPedidosDiogoVinicius;

public class Tecnico extends Funcionario implements IEspecificacaoTecnica, IServicos {
	private double valorVisita;
	
	
	@Override
	public double calcularSalario() {
		return (this.salario + valorVisita);
	}
        
	public Tecnico(){
		
	}
	public Tecnico(String nome, int matricula, String telefone, String email, String cidade, String estado,
			double salario, double valorVisita) {
		this.nome = nome;
		this.matricula = matricula;
		this.telefone = telefone;
		this.email = email;
		this.cidade = cidade;
		this.estado = estado;
		this.salario = salario;
		this.valorVisita = valorVisita;
	}

	public void mostrarDadosTecnico() {
		
		System.out.println("DADOS DO T�CNICO\n");
		System.out.println("Nome..........:" + nome + "\n");
		System.out.println("Matricula.....:" + matricula + "\n");
		System.out.println("Telefone......:" + telefone + "\n");
		System.out.println("Cidade........:" + cidade + "\n");
		System.out.println("Estado........:" + estado + "\n");
		System.out.println("Salario.......:" + salario + "\n");
		System.out.println("Valor T�cnico.:" + valorVisita + "\n");
	}

	public void mostrarServi�os() {
		System.out.println("INTEFACE:\n MOSTRA ESPECIFICA��O T�CNICA");

	}

	public void mostrarEspecificacaoTecnica() {
		System.out.println("INTEFACE:\n MOSTRA SERVI�O");
	}

	public double getValorVisita() {
		return valorVisita;
	}

	public void setValorVisita(double valorVisita) {
		
		if (valorVisita < 0) {
			throw new IllegalArgumentException(
					"AGENTE DE ERRO: \n Mensagem original: Classe T�cnico: ValorT�cnico n�o pode ser negativo ");
		} else{
			this.valorVisita = valorVisita;
		}
		
		
		this.valorVisita = valorVisita;
	}

}
