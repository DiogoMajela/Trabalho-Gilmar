package pkgClientesPedidosDiogoVinicius;

public class GerenteAdministrativo extends Gerente {
	private String nomeDaGerenciaAdministrativa;

	// D�vida toda vez que uma classe herda de outra devo criar o construtor da
	// super classe?
	public GerenteAdministrativo(String nome, int matricula, String telefone, String email, String cidade,
			String estado, double salario) {
		super(nome, matricula, telefone, email, cidade, estado, salario);

	}
	
	public GerenteAdministrativo(){
		
	}

	public String getNomeDaGerenciaAdministrativa() {
		return nomeDaGerenciaAdministrativa;
	}

	public void setNomeDaGerenciaAdministrativa(String nomeDaGerenciaAdministrativa) {
		this.nomeDaGerenciaAdministrativa = nomeDaGerenciaAdministrativa;
	}

}
