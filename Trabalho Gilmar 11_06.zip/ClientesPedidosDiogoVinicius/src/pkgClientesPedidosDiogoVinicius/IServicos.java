package pkgClientesPedidosDiogoVinicius;

public interface IServicos {
	
	public void mostrarServi�os();

}
