package pkgClientesPedidosDiogoVinicius;

public class Vendedor extends Funcionario {
	private double comissao;

	@Override
	public double calcularSalario() {
		return (this.salario + comissao);
	}

	public Vendedor() {

	}

	public Vendedor(String nome, int matricula, String telefone, String email, String cidade, String estado,
			double salario) {
		this.nome = nome;
		this.matricula = matricula;
		this.telefone = telefone;
		this.email = email;
		this.cidade = cidade;
		this.estado = estado;
		this.salario = salario;

	}

	public void mostrarDadosVendedor() {
		System.out.println("DADOS DO VENDEDOR\n");
		System.out.println("Nome.....:" + nome + "\n");
		System.out.println("Matricula:" + matricula + "\n");
		System.out.println("Telefone.:" + telefone + "\n");
		System.out.println("Cidade...:" + cidade + "\n");
		System.out.println("Estado...:" + estado + "\n");
		System.out.println("Salario..:" + salario + "\n");
		System.out.println("Comiss�o.:" + comissao + "\n");
	}

	public double getComissao() {
		return comissao;

	}

	public void setComissao(double comissao) {
		if (comissao < 0) {
			throw new IllegalArgumentException(
					"AGENTE DE ERRO: \n Mensagem original: Classe Vendedor: comiss�o n�o pode ser negativo");
		} else {
			this.comissao = comissao;
		}
	}

}
