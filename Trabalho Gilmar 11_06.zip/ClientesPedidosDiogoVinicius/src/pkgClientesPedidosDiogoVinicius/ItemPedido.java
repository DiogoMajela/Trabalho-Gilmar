package pkgClientesPedidosDiogoVinicius;

public class ItemPedido {
	
	private double valorUnitario;
	private int quantidade;
	private String descricao;
	private double desconto;
	
	//ItemPedido ip;
	
	
	public ItemPedido() {
		
	}
	public double getValorUnitario() {
		return valorUnitario;
	}
	public void setValorUnitario(double valorUnitario) {
		this.valorUnitario = valorUnitario;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getDesconto() {
		return desconto;
	}
	public void setDesconto(double desconto) {
		this.desconto = desconto;
	}

}
