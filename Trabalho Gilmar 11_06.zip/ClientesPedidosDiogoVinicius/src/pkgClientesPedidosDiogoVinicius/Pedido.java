package pkgClientesPedidosDiogoVinicius;

public class Pedido {
	private String data;
	private double valorTotal;
	private String localDeEntrega;
	private String nomeEmpresa;
	private String cnpj;
	private String contato;
	ItemPedido Ipedido; // composi��o

	public Pedido() {

	}

	// construtor da classe pedido recebendo par�metros da classe ItemPedido
	public Pedido(ItemPedido Ipedido, double valorIP, int quant, String descr, double desc) {
		Ipedido.setValorUnitario(valorIP);
		Ipedido.setQuantidade(quant);
		Ipedido.setDescricao(descr);
		Ipedido.setDesconto(desc);
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getLocalDeEntrega() {
		return localDeEntrega;
	}

	public void setLocalDeEntrega(String localDeEntrega) {
		this.localDeEntrega = localDeEntrega;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getContato() {
		return contato;
	}

	public void setContato(String contato) {
		this.contato = contato;
	}

}
