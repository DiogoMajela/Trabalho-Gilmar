package pkgClientesPedidosDiogoVinicius;

public class Gerente extends Funcionario {
	private double taxaVenda;

	@Override
	public double calcularSalario() {
		return (this.salario + taxaVenda);
	}

	public Gerente() {

	}

	public Gerente(String nome, int matricula, String telefone, String email, String cidade, String estado,
			double salario) {
		this.nome = nome;
		this.matricula = matricula;
		this.telefone = telefone;
		this.email = email;
		this.cidade = cidade;
		this.estado = estado;
		this.salario = salario;
	}

	public void mostrarDadosGerente() {
		System.out.println("DADOS DO GERENTE\n");
		System.out.println("Nome........:" + nome + "\n");
		System.out.println("Matricula...:" + matricula + "\n");
		System.out.println("Telefone....:" + telefone + "\n");
		System.out.println("Cidade......:" + cidade + "\n");
		System.out.println("E-mail......:" + email + "\n");
		System.out.println("Estado......:" + estado + "\n");
		System.out.println("Salario.....:" + salario + "\n");
		System.out.println("Taxa Venda..:" + taxaVenda + "\n");
	}

	public double getTaxaVenda() {
		return taxaVenda;
	}

	public void setTaxaVenda(double taxaVenda) {
		if (taxaVenda < 0) {
			throw new IllegalArgumentException(
					"AGENTE DE ERRO: \n Mensagem original: Classe Gerente: taxaVenda n�o pode ser negativo ");
		} else{
			this.taxaVenda = taxaVenda;
		}
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
}
