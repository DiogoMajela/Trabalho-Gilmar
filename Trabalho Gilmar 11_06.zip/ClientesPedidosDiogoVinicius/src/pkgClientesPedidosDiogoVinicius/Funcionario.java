package pkgClientesPedidosDiogoVinicius;

public abstract class Funcionario {
	protected String nome;
	protected int matricula;
	protected String telefone;
	protected String email;
	protected String cidade;
	protected String estado;
	protected double salario;

	abstract double calcularSalario();

}
