package pkgClientesPedidosDiogoVinicius;

public class GerenteFinanceiro extends Gerente {
	private String nomeDaGerenciaFinanceira;

	public GerenteFinanceiro(String nome, int matricula, String telefone, String email, String cidade, String estado,
			double salario) {
		super(nome, matricula, telefone, email, cidade, estado, salario);
	}

	public GerenteFinanceiro() {

	}

	public String getNomeDaGerenciaFinanceira() {
		return nomeDaGerenciaFinanceira;
	}

	public void setNomeDaGerenciaFinanceira(String nomeDaGerenciaFinanceira) {
		this.nomeDaGerenciaFinanceira = nomeDaGerenciaFinanceira;
	}

}
