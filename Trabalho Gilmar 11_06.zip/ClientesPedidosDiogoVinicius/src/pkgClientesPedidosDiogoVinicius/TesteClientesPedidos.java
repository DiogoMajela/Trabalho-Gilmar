/*
 * PROGRAMA CLIENTES E PEDIDOS
 * DATA: MAIO/JUNHO DE 2017
 * EQUIPE:
 * DIOGO MAJELA CORREA LOPES
 * 
 */

package pkgClientesPedidosDiogoVinicius;

import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;

public class TesteClientesPedidos {
	static Scanner leitura = new Scanner(System.in);
	static Scanner lerVendedor = new Scanner(System.in);
	static Scanner lerTecnico = new Scanner(System.in);
	static Gerente ge;
	static Vendedor ve;
	static Tecnico te;
	static ItemPedido ip;
	static Pedido cadastroPedido;
	static GerenteAdministrativo gerAdm;
	static GerenteFinanceiro gerFinanceiro;
	static int quant, qtdAcessoMenu = 1, opcao;
	static String descr;
	static double desc, taxaVenda, valorUnitario;

	public static void main(String[] args) throws IOException {
		menu();

	}

	static void menu() throws IOException {

		do {
			qtdAcessoMenu++;
			System.out.println("\nPROGRAMA CLIENTES/PEDIDOS - OP��ES\n");
			System.out.println("----------------------------------\n");
			System.out.println("1  - Cadastrar Gerente\n");
			System.out.println("2  - Cadastrar Vendedor\n");
			System.out.println("3  - Cadastrar T�cnico\n");
			System.out.println("4  - Mostrar dados dos funcionarios(Gerente/Vendedor/T�cnico\n");
			System.out.println("5  - Cadastrar Item de Pedido\n");
			System.out.println("6  - Cadastrar Pedido\n");
			System.out.println("7  - Mostrar Dados de Pedido e Item de Pedido\n");
			System.out.println("8  - Cadastrar Gerente Administrativo\n");
			System.out.println("9  - Cadastrar Gerente Financeiro\n");
			System.out.println("10 - Mostrar dados de Gerente Administrativo e Financeiro\n");
			System.out.println("11 - Mostrar c�lculo do sal�rio para cada funcionario (Gerente/Vendedor/T�cnico\n");
			System.out.println("12 - Sobre\n");
			System.out.println("13 - Encerrar programa\n");

			System.out.println("Informe a op��o:");
			opcao = leitura.nextInt();
			leitura.nextLine();
			switch (opcao) {
			case 1:
				cadastrarGerente();
				break;
			case 2:
				cadastrarVendedor();
				break;
			case 3:
				cadastrarTecnico();
				break;
			case 4:
				ge.mostrarDadosGerente();
				System.out.println("\n");
				ve.mostrarDadosVendedor();
				System.out.println("\n");
				te.mostrarDadosTecnico();
			case 5:
				cadastrarItemPedido();
				break;
			case 6:
				cadastrarPedido();
				break;
			case 7:
				mostrarDadosPedidoItemPedido();
				break;
			case 8:
				cadastrarGerenteAdministrativo();
				break;
			case 9:
				cadastrarGerenteFinanceiro();
				break;
			case 10:
				mostrarDadosGerentes();
				break;
			case 11:
				mostrarSalarioFuncionario();
			case 12:
				sobre();
			case 13:
				System.out.println(">>PROGRAMA FINALIZADO");
				break;
			}

		} while (opcao != 13);
		leitura.close();
	}

	public static void cadastrarGerente() {
		ge = new Gerente();

		System.out.println("CADASTRAR GERENTE\n");
		System.out.println("Nome:........:");
		ge.setNome(leitura.nextLine());

		System.out.println("Matricula:...:");
		ge.setMatricula(leitura.nextInt());

		System.out.println("Telefone:....:");
		ge.setTelefone(leitura.next());

		System.out.println("Cidade:......:");
		ge.setCidade(leitura.next());

		System.out.println("E-mail:......:");
		ge.setEmail(leitura.next());

		System.out.println("Sal�rio:.....:");
		ge.setSalario(leitura.nextDouble());

		System.out.println("Estado:......:");
		ge.setEstado(leitura.next());

		try {
			System.out.println("Taxa Venda:..:");
			taxaVenda = leitura.nextDouble();
			ge.setTaxaVenda(taxaVenda);

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
			System.out.println("Taxa Venda:..:");
			taxaVenda = leitura.nextDouble();
			ge.setTaxaVenda(taxaVenda);
		}
		System.out.println("DADOS DO GERENTE CADASTRADO COM SUCESSO");
	}

	public static void cadastrarVendedor() {

		ve = new Vendedor();

		System.out.println("CADASTRAR VENDEDOR\n");
		System.out.println("Nome:........:");
		ve.nome = lerVendedor.nextLine();

		System.out.println("Matricula:...:");
		ve.matricula = lerVendedor.nextInt();

		System.out.println("Telefone:....:");
		ve.telefone = lerVendedor.next();

		System.out.println("Cidade:......:");
		ve.cidade = lerVendedor.next();

		System.out.println("E-mail:......:");
		ve.email = lerVendedor.next();

		System.out.println("Sal�rio:.....:");
		ve.salario = lerVendedor.nextDouble();

		System.out.println("Estado:......:");
		ve.estado = lerVendedor.next();

		try {
			System.out.println("Comiss�o:..:");
			ve.setComissao(leitura.nextDouble());

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
			System.out.println("Comiss�o:..:");
			ve.setComissao(leitura.nextDouble());
		}
		System.out.println("DADOS DO VENDEDOR CADASTRADO COM SUCESSO");
	}

	public static void cadastrarTecnico() {

		te = new Tecnico();

		System.out.println("CADASTRAR VENDEDOR\n");
		System.out.println("Nome:........:");
		te.nome = lerTecnico.next();

		System.out.println("Matricula:...:");
		te.matricula = lerTecnico.nextInt();

		System.out.println("Telefone:....:");
		te.telefone = lerTecnico.next();

		System.out.println("Cidade:......:");
		te.cidade = lerTecnico.next();

		System.out.println("E-mail:......:");
		te.email = lerTecnico.next();

		System.out.println("Sal�rio:.....:");
		te.salario = lerTecnico.nextDouble();

		System.out.println("Estado:......:");
		te.estado = lerTecnico.next();

		try {
			System.out.println("Valor T�cnico:..:");
			te.setValorVisita(lerTecnico.nextDouble());

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
			System.out.println("Valor T�cnico:..:");
			te.setValorVisita(lerTecnico.nextDouble());
		}

		System.out.println("DADOS DO T�CNICO CADASTRADO COM SUCESSO");
	}

	public static void cadastrarItemPedido() {
		ip = new ItemPedido();
		System.out.println("CADASTRAR ITEM DE PEDIDO");

		System.out.println("Valor Unit�rio.: ");
		valorUnitario = leitura.nextDouble();

		System.out.println("Quantidade.....:");
		quant = leitura.nextInt();

		System.out.println("Descri��o......:");
		descr = leitura.next();

		System.out.println("Desconto.......:");
		desc = leitura.nextDouble();

	}

	public static void cadastrarPedido() {

		cadastroPedido = new Pedido(ip, valorUnitario, quant, descr, desc);
		System.out.println("CADASTRAR PEDIDO");

		System.out.println("Data ...........:");
		cadastroPedido.setData(leitura.next());

		System.out.println("Local entrega...:");
		cadastroPedido.setLocalDeEntrega(leitura.next());

		System.out.println("Nome da empresa.:");
		cadastroPedido.setNomeEmpresa(leitura.next());

		System.out.println("CNPJ............:");
		cadastroPedido.setCnpj(leitura.next());

		System.out.println("Contato.........:");
		cadastroPedido.setContato(leitura.next());

		cadastroPedido.setValorTotal(valorUnitario * quant - desc);

	}

	public static void mostrarDadosPedidoItemPedido() {
		System.out.println("DADOS DO PEDIDO");
		System.out.println("Data............:" + cadastroPedido.getData());

		System.out.println("Valor Total.....:" + cadastroPedido.getValorTotal());

		System.out.println("Local entrega...:" + cadastroPedido.getLocalDeEntrega());

		System.out.println("Nome da empresa.:" + cadastroPedido.getNomeEmpresa());

		System.out.println("CNPJ............:" + cadastroPedido.getCnpj());

		System.out.println("Contato.........:" + cadastroPedido.getContato());

		System.out.println("---------------------------");

		System.out.println("Valor Unit�rio.:" + ip.getValorUnitario());

		System.out.println("Quantidade.....:" + ip.getQuantidade());

		System.out.println("Descri��o......:" + ip.getDescricao());

		System.out.println("Desconto.......:" + ip.getDesconto());

	}

	public static void cadastrarGerenteAdministrativo() {

		gerAdm = new GerenteAdministrativo();

		System.out.println("CADASTRAR GERENTE ADMINISTRATIVO");

		System.out.println("Nome...........:");
		gerAdm.setNome(leitura.nextLine());

		System.out.println("Matricula......:");
		gerAdm.setMatricula(leitura.nextInt());

		System.out.println("Telefone.......:");
		gerAdm.setTelefone(leitura.next());

		System.out.println("Cidade.........:");
		gerAdm.setCidade(leitura.next());

		System.out.println("Email..........:");
		gerAdm.setEmail(leitura.next());

		System.out.println("Sal�rio........:");
		gerAdm.setSalario(leitura.nextDouble());

		System.out.println("Estado.........:");
		gerAdm.setEstado(leitura.next());

		try {
			System.out.println("Taxa Venda:..:");
			gerAdm.setTaxaVenda(leitura.nextDouble());

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("Nome Ger�ncia..:");
		gerAdm.setNomeDaGerenciaAdministrativa(leitura.next());

	}

	public static void cadastrarGerenteFinanceiro() {

		gerFinanceiro = new GerenteFinanceiro();

		System.out.println("CADASTRAR GERENTE ADMINISTRATIVO");

		System.out.println("Nome...........:");
		gerFinanceiro.setNome(leitura.nextLine());

		System.out.println("Matricula......:");
		gerFinanceiro.setMatricula(leitura.nextInt());

		System.out.println("Telefone.......:");
		gerFinanceiro.setTelefone(leitura.next());

		System.out.println("Cidade.........:");
		gerFinanceiro.setCidade(leitura.next());

		System.out.println("Email..........:");
		gerFinanceiro.setEmail(leitura.next());

		System.out.println("Sal�rio........:");
		gerFinanceiro.setSalario(leitura.nextDouble());

		System.out.println("Estado.........:");
		gerFinanceiro.setEstado(leitura.next());

		try {
			System.out.println("Taxa Venda:..:");
			gerFinanceiro.setTaxaVenda(leitura.nextDouble());

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("Nome Ger�ncia..:");
		gerFinanceiro.setNomeDaGerenciaFinanceira(leitura.next());

	}

	public static void mostrarDadosGerentes() {
		System.out.println("CONSULTAR DADOS DA GER�NCIA ADMINISTRATIVA E FINANCEIRA");

		System.out.println("GER�NCIA ADMINISTRATIVA");
		System.out.println("Nome:..........:" + gerAdm.getNome());
		System.out.println("Matricula......:" + gerAdm.getMatricula());
		System.out.println("Telefone.......:" + gerAdm.getTelefone());
		System.out.println("Cidade.........:" + gerAdm.getCidade());
		System.out.println("E-mail.........:" + gerAdm.getEmail());
		System.out.println("Sal�rio........:" + gerAdm.getSalario());
		System.out.println("Estado.........:" + gerAdm.getEstado());
		System.out.println("Taxa venda.....:" + gerAdm.getTaxaVenda());
		System.out.println("Nome Ger�ncia..:" + gerAdm.getNomeDaGerenciaAdministrativa());

		System.out.println("\nGER�NCIA ADMINISTRATIVA");
		System.out.println("Nome:..........:" + gerFinanceiro.getNome());
		System.out.println("Matricula......:" + gerFinanceiro.getMatricula());
		System.out.println("Telefone.......:" + gerFinanceiro.getTelefone());
		System.out.println("Cidade.........:" + gerFinanceiro.getCidade());
		System.out.println("E-mail.........:" + gerFinanceiro.getEmail());
		System.out.println("Sal�rio........:" + gerFinanceiro.getSalario());
		System.out.println("Estado.........:" + gerFinanceiro.getEstado());
		System.out.println("Taxa venda.....:" + gerFinanceiro.getTaxaVenda());
		System.out.println("Nome Ger�ncia..:" + gerFinanceiro.getNomeDaGerenciaFinanceira());

	}

	public static void mostrarSalarioFuncionario() {

		ArrayList<Funcionario> listaFunc = new ArrayList<Funcionario>();
		listaFunc.add(ge);
		listaFunc.add(te);
		listaFunc.add(ve);
		System.out.println("CALCULO SALARIO DO FUNCIONARIO");

		for (int i = 0; i < listaFunc.size(); i++) {

			if (listaFunc.get(i) instanceof Gerente) {
				System.out.println("Classe...:Gerente");
				System.out.println("Sal�rio..:" + ge.calcularSalario() + "\n");
				;
			}

			else if (listaFunc.get(i) instanceof Vendedor) {
				System.out.println("Classe...:Vendedor");
				System.out.println("Sal�rio..:" + ve.calcularSalario() + "\n");
				;
			}

			else if (listaFunc.get(i) instanceof Tecnico) {
				System.out.println("Classe...:T�cnico");
				System.out.println("Sal�rio..:" + te.calcularSalario() + "\n");
			}
		}

	}

	public static void sobre() {

		System.out.println("SOBRE O PROGRAMA CLIENTES/PEDIDOS");
		System.out.println("---------------------------------------");
		System.out.println("EQUIPE\n");
		System.out.println("Diogo Majela Corr�a Lopes");
		System.out.println("Vinicius \nMAIO 2017");
		System.out.println("Quantidade de acessos ao menu do programa: " + qtdAcessoMenu);

	}
}