package pkgClientesPedidosDiogoVinicius;

public interface IEspecificacaoTecnica {

	public void mostrarEspecificacaoTecnica();
		
	
}
